//
//  User.swift
//  BacSiGanNha
//
//  Created by devsenior on 08/08/2023.
//

import Foundation

struct User {
    let phoneNumber: String
    
    init(phoneNumber: String) {
        self.phoneNumber = phoneNumber
    }
}
