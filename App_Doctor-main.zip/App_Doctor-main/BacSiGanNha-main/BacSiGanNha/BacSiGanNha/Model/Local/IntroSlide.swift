//
//  IntroSlide.swift
//  BacSi_App
//
//  Created by devsenior on 17/07/2023.
//

import Foundation
import UIKit

struct Intro {
    var title: String
    var description: String
    let image: String
    
}
